# Alert for startup Application


<div style="text-align: center;">
<b>Preview</b><br>

<img src="https://raw.githubusercontent.com/x2niosvn/Custom-application-startup-notification-Theos/main/IMAGE.jpg">
</div>


# About
- This is an alert template for popup modification application
- Support injection with CydiaSubstrate.framework
- This popup can be used for watermark purpose
- Fan boi of「彼女、お借りします」

# Installation
- Using theos for compilation


# Feature
- Show up a button that you can customize
- Can inject to decrypted iPA for popup

# Usage
**Change the plist to bundle id you want to test it on jailbroken device**

### Pull request button is on the top, you can contribute to this project if you want

# Credits
- [x2nios](https://github.com/x2niosvn)
- Huy Nguyen [34306](https://github.com/34306)

